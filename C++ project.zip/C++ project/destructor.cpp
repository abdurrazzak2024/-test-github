#include <iostream>

class MyArray {
private:
    int* arr;
    int size;

public:
    // Constructor
    MyArray(int s) : size(s) {
        arr = new int[size]; // Allocate memory
        for (int i = 0; i < size; ++i) {
            arr[i] = i; // Initialize the array
        }
        std::cout << "Array created of size " << size << ".\n";
    }

    // Destructor
    ~MyArray() {
        delete[] arr; // Free allocated memory
        std::cout << "Array destroyed.\n";
    }

    // Function to display the array
    void display() const {
        for (int i = 0; i < size; ++i) {
            std::cout << arr[i] << " ";
        }
        std::cout << std::endl;
    }
};

int main() {
    MyArray myArray(5); // Create an object of MyArray
    myArray.display();   // Display the array

    // No need to manually delete myArray; the destructor will be called automatically
    return 0;
}

