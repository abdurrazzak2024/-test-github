#include <iostream>
#include <cstdlib> // For rand() and srand()
#include <ctime>   // For time()
using namespace std;

int main() {
    srand(static_cast<unsigned int>(time(0))); // Seed for random number generation

    string choices[3] = {"Rock", "Paper", "Scissors"};
    int userChoice;
    int computerChoice;

    cout << "Welcome to Rock-Paper-Scissors!" << endl;
    cout << "Choose an option: " << endl;
    cout << "0: Rock" << endl;
    cout << "1: Paper" << endl;
    cout << "2: Scissors" << endl;
    cout << "Enter your choice (0-2): ";
    cin >> userChoice;

    if (userChoice < 0 || userChoice > 2) {
        cout << "Invalid choice. Please run the program again." << endl;
        return 1; // Exit the program with an error
    }

    computerChoice = rand() % 3; // Random choice for computer

    cout << "You chose: " << choices[userChoice] << endl;
    cout << "Computer chose: " << choices[computerChoice] << endl;

    // Determine the winner
    if (userChoice == computerChoice) {
        cout << "It's a tie!" << endl;
    } else if ((userChoice == 0 && computerChoice == 2) ||
               (userChoice == 1 && computerChoice == 0) ||
               (userChoice == 2 && computerChoice == 1)) {
        cout << "You win!" << endl;
    } else {
        cout << "You lose!" << endl;
    }

    return 0;
}
