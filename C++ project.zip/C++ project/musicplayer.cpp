
#include <iostream>

int main() {
    // Create a music object
    sf::Music music;

    // Load a music file
    if (!music.openFromFile("music.ogg")) { // Replace with your music file path
        std::cerr << "Error loading music file!" << std::endl;
        return -1;
    }

    // Play the music
    music.play();

    std::cout << "Playing music. Press Enter to stop..." << std::endl;

    // Keep the program running until Enter is pressed
    std::cin.get();

    // Stop the music
    music.stop();

    return 0;
}
