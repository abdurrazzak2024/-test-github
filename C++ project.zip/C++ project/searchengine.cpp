#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <sstream>

using namespace std;

class Document {
public:
    string filename;
    string content;

    Document(const string& name) : filename(name) {
        loadContent();
    }

    void loadContent() {
        ifstream file(filename);
        if (file.is_open()) {
            stringstream buffer;
            buffer << file.rdbuf();
            content = buffer.str();
            file.close();
        } else {
            cerr << "Could not open file: " << filename << endl;
        }
    }
};

class SearchEngine {
private:
    vector<Document> documents;

public:
    void addDocument(const string& filename) {
        documents.emplace_back(filename);
    }

    void search(const string& keyword) {
        cout << "Searching for: " << keyword << endl;
        bool found = false;

        for (const auto& doc : documents) {
            if (doc.content.find(keyword) != string::npos) {
                cout << "Found in: " << doc.filename << endl;
                found = true;
            }
        }

        if (!found) {
            cout << "No documents found containing the keyword: " << keyword << endl;
        }
    }
};

int main() {
    SearchEngine searchEngine;

    // Add documents (text files) to the search engine
    searchEngine.addDocument("doc1.txt");
    searchEngine.addDocument("doc2.txt");
    searchEngine.addDocument("doc3.txt");

    string keyword;
    cout << "Enter keyword to search: ";
    cin >> keyword;

    searchEngine.search(keyword);

    return 0;
}

