#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Contact {
    string name;
    string phoneNumber;
};

class Phonebook {
private:
    vector<Contact> contacts;

public:
    void addContact(const string& name, const string& phoneNumber) {
        contacts.push_back({name, phoneNumber});
        cout << "Contact added successfully." << endl;
    }

    void searchContact(const string& name) {
        bool found = false;
        for (const auto& contact : contacts) {
            if (contact.name == name) {
                cout << "Name: " << contact.name << ", Phone Number: " << contact.phoneNumber << endl;
                found = true;
                break;
            }
        }
        if (!found) {
            cout << "Contact not found." << endl;
        }
    }

    void displayContacts() {
        if (contacts.empty()) {
            cout << "No contacts in the phonebook." << endl;
            return;
        }
        cout << "Phonebook Contacts:" << endl;
        for (const auto& contact : contacts) {
            cout << "Name: " << contact.name << ", Phone Number: " << contact.phoneNumber << endl;
        }
    }
};

int main() {
    Phonebook phonebook;
    int choice;

    do {
        cout << "\nPhonebook Menu:" << endl;
        cout << "1. Add Contact" << endl;
        cout << "2. Search Contact" << endl;
        cout << "3. Display All Contacts" << endl;
        cout << "4. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1: {
                string name, phoneNumber;
                cout << "Enter name: ";
                cin.ignore(); // Clear input buffer
                getline(cin, name);
                cout << "Enter phone number: ";
                getline(cin, phoneNumber);
                phonebook.addContact(name, phoneNumber);
                break;
            }
            case 2: {
                string name;
                cout << "Enter name to search: ";
                cin.ignore(); // Clear input buffer
                getline(cin, name);
                phonebook.searchContact(name);
                break;
            }
            case 3:
                phonebook.displayContacts();
                break;
            case 4:
                cout << "Exiting the phonebook application." << endl;
                break;
            default:
                cout << "Invalid choice. Please try again." << endl;
        }
    } while (choice != 4);

    return 0;
}

