#include <iostream>
#include <cstdlib> // For rand() and srand()
#include <ctime>   // For time()
using namespace std;

int main() {
    srand(static_cast<unsigned int>(time(0))); // Seed for random number generation

    const int MIN_NUMBER = 1;
    const int MAX_NUMBER = 100;
    const int MAX_ATTEMPTS = 7;

    int randomNumber = rand() % (MAX_NUMBER - MIN_NUMBER + 1) + MIN_NUMBER;
    int guess;
    int attempts = 0;

    cout << "Welcome to the Casino Number Guessing Game!" << endl;
    cout << "Guess a number between " << MIN_NUMBER << " and " << MAX_NUMBER << "." << endl;
    cout << "You have " << MAX_ATTEMPTS << " attempts to guess the correct number." << endl;

    while (attempts < MAX_ATTEMPTS) {
        cout << "Attempt " << (attempts + 1) << ": ";
        cin >> guess;

        if (guess < MIN_NUMBER || guess > MAX_NUMBER) {
            cout << "Please guess a number within the valid range!" << endl;
            continue; // Skip to the next iteration if the guess is out of range
        }

        attempts++;

        if (guess == randomNumber) {
            cout << "Congratulations! You guessed the correct number: " << randomNumber << "!" << endl;
            break; // Exit the loop if the guess is correct
        } else if (guess < randomNumber) {
            cout << "Too low! Try again." << endl;
        } else {
            cout << "Too high! Try again." << endl;
        }
    }

    if (attempts == MAX_ATTEMPTS) {
        cout << "Sorry, you've used all your attempts. The correct number was: " << randomNumber << "." << endl;
    }

    return 0;
}

